/*
Copyright (c) 2018 Andy Cox V artcomp.c

Author: Andy Cox V
Date: 1/8/2018
Program: artcomp.bin
Source Code File Name: artcomp.c
Programming Language: C
Compiler: gcc
Compiler Options: gcc artcomp.c -oartcomp.bin
Example Execution Options: ./artcomp.bin -S 100 -H 4096 -W 4096 -R 0.4 -I 0.6 -M 65535 -O outputfile.bmp -C configfile.txt -w 1200 -h 1200
Description: Produces Julia set fractals for an art competition.

Notes:
	- BMP files store data from bottom right of an image to the top left.
	- 24-bit BMP files store pixel information in BGR format where each model color is 8-bits long.
	
BMP first 54 bytes header info...

	--- 14 bytes total ---

	short bmpft;	"BM" file header. <--- defined
	unsigned int bmp_size;	Dword for the file size. <--- variable
	int reserved;	Two shorts that will always be set to zero! <--- defined
	unsigned int bmpstart;	The start of the data bits decimal 54! <--- defined
	
	--- 40 bytes total ---
	
	unsigned int infosize;	The number of required bytes for this section 40! <--- defined
	int width;	The width of the image in pixels. <=== USER DEFINED VARIABLE
	int height;	The height of the image in pixels. <=== USER DEFINED VARIABLE
	short planes;	The number of visible planes always set to 1! <--- defined
	short bitcount;	Can be set to different depths, but 24-bits will be used! <--- defined
	unsigned int compression;	Set to zero so no compression is used! <--- defined
	unsigned int imagesize;	Set to zero since no compression is used! <--- defined
	int xpixelpermeter;	Set the horizontal image resolution. <=== USER DEFINED VARIABLE 
	int ypixelpermeter;	Set the vertical image resolution. <=== USER DEFINED VARIABLE 
	unsigned int colorindexes;	Set to zero so the maximum is used! <--- defined
	unsigned int colorimportant;	Set to zero because all colors are important! <--- defined
	
BMP Pixel Information

	NOTE: DO NOT PUT IN STRUCTS! It is easier to "see", but code wise due to the padding implementation
	that compilers use on structs it is ineffecent, not cross compiler, and troublesome.
	Gcc did not like program_data[location++]; it perfered program_data[location] <NEW LINE> location++;
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* Misc. variables for the creation of a bitmap image (*.bmp) file. */
#define DATA_START 54 /* Start of data segment offset in the code and also size of the file header. */
#define INFO_SIZE 40 /* Size of the information header. */
#define PLANES 1 /* Number of visible planes. */
#define BITCOUNT 24 /* Number of bits per pixel. */
#define BYTES_PER_PIXEL 3 /* Number of bytes per pixel. */
#define COMPRESSION_AND_IMAGESIZE 0 /* Set to zero so no compression and not needed image size. */
#define COLOR_INDEX_AND_IMPORTANT 0 /* No important colors and no color index. */

/* Keywords used in the programming language. */
#define SEPERATOR ' ' /* Blank space used as a seperator. */
#define TERMINATOR "end" /* Used to terminate a script file. */
#define INTEGER_INTO_INTEGER "omninteger" /* Used to denote all operations mutate the integer stack. */
#define DOUBLE_INTO_DOUBLE "omnireal" /* Used to denote all operations mutate the double stack. */
#define INTEGER_INTO_DOUBLE "archreal" /* Used to denote all arithmatic operations mutate both stacks and the result is stored in real. */
#define DOUBLE_INTO_INTEGER "archinteger" /* Used to denote all arithmatic operations mutate both stacks and the result is stored in integer. */

/* Computed variables from the Julia Set algorithm. */
#define Y_COORDINATE "coordinateY"
#define X_COORDINATE "coordinateX"
#define CI "complexImaginary"
#define CR "complexReal"
#define CYCLES "cycles"
#define ELEMENTS "location" /* More fitting name because of indexing. */

/* Stack based manipulation operators. */
#define POP "pop"
#define PUSH "push"
#define ROT "rotate"
#define SWAP "swap"
#define DUP "duplicate"
#define OVER "over"
#define EXCHANGE "exchange"

/* Arithmatic operators. */
#define ADD "add"
#define SUB "subtract"
#define MUL "multiply"
#define DIV "divide"
#define MOD "modulus"

/* Binary operators. */
#define SHL "shiftLeft"
#define SHR "shiftRight"
#define OR "or"
#define XOR "xor"
#define AND "and"
#define NOT "not"

/* Used for branching. */
#define LESS "gotoLess"
#define GREATER "gotoGreater"
#define EQUAL "gotoEqual"
#define NOTEQUAL "gotoNotEqual"
#define UNCONDITIONAL "goto"
#define LABEL "label"
#define CALL "call"
#define RETURN "return"

/* Used for more less structured use of the stack. Peek, Poke, and Elements. */
#define PEEK "peek"
#define POKE "poke"

/* Used for looping. */
#define TRUE -1 /* All bits set to one. */
#define FALSE 0

/* Comments. */
#define START_OF_COMMENT '['
#define END_OF_COMMENT ']'

/* Computed variables from the Julia Set algorithm. */
#define Y_COORDINATE_NUMBER 0
#define X_COORDINATE_NUMBER 1
#define CI_NUMBER 2
#define CR_NUMBER 3
#define CYCLES_NUMBER 4
#define ELEMENTS_NUMBER 5
#define PUSH_VARS 6

/* Stack based manipulation operators. */
#define POP_NUMBER 6
#define PUSH_NUMBER 7
#define ROT_NUMBER 8
#define SWAP_NUMBER 9
#define DUP_NUMBER 10
#define OVER_NUMBER 11

/* Arithmatic operators. */
#define ADD_NUMBER 12
#define SUB_NUMBER 13
#define MUL_NUMBER 14
#define DIV_NUMBER 15
#define MOD_NUMBER 16

/* Binary operators. */
#define SHL_NUMBER 17
#define SHR_NUMBER 18
#define OR_NUMBER 19
#define XOR_NUMBER 20
#define AND_NUMBER 21
#define NOT_NUMBER 22

/* Used for branching. */
#define LESS_NUMBER 23
#define GREATER_NUMBER 24
#define EQUAL_NUMBER 25
#define NOTEQUAL_NUMBER 26
#define UNCONDITIONAL_NUMBER 27
#define LABEL_NUMBER 28
#define CALL_NUMBER 29
#define RETURN_NUMBER 30

/* Used for more less structured use of the stack. Peek, Poke, and Elements. */
#define PEEK_NUMBER 31
#define POKE_NUMBER 32

#define TERMINATOR_NUMBER 33

#define INTEGER_STACK_NUMBER 34
#define DOUBLE_STACK_NUMBER 35
#define ARCH_REAL_STACK_NUMBER 36
#define ARCH_INTEGER_STACK_NUMBER 37
#define EXCHANGE_NUMBER 38

/* Misc. defines. */
#define ARGUMENTS 21 /* The number of arguments the program must pass (10 flags 10 arguments 1 program 1 + 10 + 10 = 21). */
#define COMPUTATION_ARGUMENT_COUNT 20 /* Number of arguments minus the program file name. */
#define INTEGER_STACK 0
#define DOUBLE_STACK 1
#define ARCH_REAL_STACK 2
#define ARCH_INTEGER_STACK 3
#define MAXIMUM_LINE 100 /* Maximum number of characters for one line. */
#define MAXIMUM_RETURN_STACK 127 /* Maximum number of possible returns. */
#define MAXIMUM_LABEL 1000

/* Global Variables. */
double* Global_numeric_data; /* Pointer that will be set in load. */
unsigned int Global_stack_size = 0; /* Default setting. */
unsigned int Global_program_counter = 0;
int Global_a_stack_elements = -1; /* Have stack elements as signed since negative values are used in popping from the stack and error checking. */
int Global_b_stack_elements = -1;
int Global_c_stack_elements = -1;
double Global_cr = 0;
double Global_ci = 0;
double Global_x = 0;
double Global_y = 0;

/* Used for displaying errors. */
void error(unsigned char err)
{
	printf("ERROR: ");

	switch(err)
	{
	case 0:
		puts("Invalid character in configuration file!");
		break;
	case 1:
		puts("Stack underflow!");
		break;
	case 2:
		puts("Stack overflow!");
		break;
	case 3:
		puts("Not enough arguments!");
		break;
	case 4:
		puts("Out of memory!");
		break;
	case 5:
		puts("Unable to access file!");
		break;
	case 6:
		puts("Invalid argument!");
		break;
	case 7:
		printf("Instruction only capable in %s or %s mode!\n", INTEGER_INTO_INTEGER, DOUBLE_INTO_INTEGER);
		break;
	case 8:
		puts("Invalid instruction!");
		break;
	case 9:
		puts("Too many calls!");
		break;
	case 10:
		printf("Segmentation fault in %s or %s!\n", PEEK, POKE);
		break;
	case 11:
		puts("Non-existant label!");
		break;
	case 12:
		puts("Nested comment or open comment!");
		break;
	default:
		puts("General error!"); /* Cannot be reached, but included for fun :) */
		break;
	}

	exit(err + 1); /* Return value of error + 1 for other programs to error handle. */
}

/* Loads the color configuration file into memory. 
Returns a character pointer to where the instructions lie in memory.*/
char* loadConfig(char* file_name)
{
	/* Read file into memory. */
	FILE *file_pointer = fopen(file_name, "r");
	
	if(file_pointer == NULL) /* The file does not exist. */
		error(5); 

	char white_space[3] = {0x09, 0x0A, 0x0D};
	unsigned int counter = 0;
	int ASCII = 0; /* EOF is an integer value. */

	/* Set aside appropriate memory for the script by finding the file's size. */
	fseek(file_pointer, 0, SEEK_END);
	char* program_space = (char*)malloc(ftell(file_pointer));
	rewind(file_pointer);

	/* Seperates the file into keywords and numbers for further processing. */
	while(ASCII != EOF)
	{
		ASCII = fgetc(file_pointer);

                /* Read past commented sections. */
                if(ASCII == START_OF_COMMENT)
                {
                        while(ASCII != END_OF_COMMENT && ASCII != EOF)
                                ASCII = fgetc(file_pointer);

			if(ASCII == EOF)
				error(12);

                        ASCII = fgetc(file_pointer);
                }

		for(char i = 0 ; i < 3 ; i++) /* Check if the ASCII character is white space. */
			if(ASCII == white_space[i])
			{
				ASCII = SEPERATOR; /* Convert whitespace into a seperator. */
				break;
			}

		if(counter > 0)
		{
			if((program_space[counter - 1] != SEPERATOR && ASCII == SEPERATOR) || (ASCII != SEPERATOR))
			{
				program_space[counter] = (char)ASCII;
				counter++;
			}
		}
		else if(counter == 0 && ASCII != SEPERATOR) /* The first character cannot be a seperator. */
		{
			program_space[0] = (char)ASCII;
			counter = 1;
		}
	}
	
	Global_program_counter = counter - 1;
	program_space[counter - 1] = ' ';
	program_space[counter] = '\0';
	fclose(file_pointer);
	return program_space;
}

/* Evaluates all of the tokens. */
unsigned int* load(char* program_space)
{
	unsigned int program_data_location = 0;
	unsigned int label_counter = 0;
	unsigned int numeric_location = 0;
	unsigned int numeric_amount = 0; /* Used for malloc for doubles. */
	unsigned int instruction_amount = 0; /* Used for malloc for the instructions. */
	unsigned int word_location = 0;
	int command = 0; /* Used to store the number for the command. */
	char label_creation = FALSE;
	char string_buffer[MAXIMUM_LINE]; /* Used to store strings.*/
	char label_array[MAXIMUM_LABEL][MAXIMUM_LINE];

	word_location = 0; /* Must be reset for next iteration! */

	while(program_space[word_location] != '\0') /* Get a count for every number. */
	{
		sscanf(program_space + word_location, "%s", string_buffer);
		word_location += strlen(string_buffer);
		word_location++;

		int i = 0;
		char num = TRUE;

		do
		{
			if(!(string_buffer[i] <= '9' && string_buffer[i] >= '0' || string_buffer[i] == '-' || string_buffer[i] == '.' || string_buffer[i] == '\0'))
				num = FALSE;
			i++;
		}while(string_buffer[i] != '\0');

		if(num == TRUE)
			numeric_amount++;
	}

	Global_numeric_data = (double*)malloc(sizeof(double) * numeric_amount); /* Set aside memory for the doubles. */

	word_location = 0; /* Must be reset for next iteration! */
	numeric_amount = 0;

	while(program_space[word_location] != '\0') /* Get a count for every instruction. */
	{
		sscanf(program_space + word_location, "%s", string_buffer);
		word_location += strlen(string_buffer);
		word_location++;
		numeric_amount++;
	}

	printf("Number of instructions and arguments: %d\n", numeric_amount);	

	unsigned int* program_data = (unsigned int*)malloc(sizeof(unsigned int) * numeric_amount);

	word_location = 0; /* Must be reset for next iteration! */

	/* Reads the program and breaks it into sections of strings to be processed. */
	while(program_space[word_location] != '\0')
	{
		sscanf(program_space + word_location, "%s", string_buffer);
		word_location += strlen(string_buffer);
		word_location++;

		if(program_space[word_location] == '\0')
			break;

		if(strcmp(string_buffer, TERMINATOR) == 0) /* Terminate the script. */
			command = TERMINATOR_NUMBER;
		else if(strcmp(string_buffer, INTEGER_INTO_INTEGER) == 0) /* Only use stack a.*/
			command = INTEGER_STACK_NUMBER;
		else if(strcmp(string_buffer, INTEGER_INTO_DOUBLE) == 0) /* Use stack a and b, and store in b.*/
			command = ARCH_REAL_STACK_NUMBER;
		else if(strcmp(string_buffer, DOUBLE_INTO_INTEGER) == 0) /* Use stack a and b, and store in a.*/
			command = ARCH_INTEGER_STACK_NUMBER;
		else if(strcmp(string_buffer, DOUBLE_INTO_DOUBLE) == 0) /* Only use stack b. */
			command = DOUBLE_STACK_NUMBER;
		else if(strcmp(string_buffer, POP) == 0) /* Pop an element from either stack a or b. */
			command = POP_NUMBER;
		else if(strcmp(string_buffer, PUSH) == 0) /* Used to store integers, variables, and doubles. */
		{
			program_data[program_data_location] = PUSH_NUMBER;
			program_data_location++;

			sscanf(program_space + word_location, "%s", string_buffer);
			word_location += strlen(string_buffer);
			word_location++;

			if(strcmp(string_buffer, CYCLES) == 0) /* Number of iterations to escape Julia set. */
				command = CYCLES_NUMBER;
			else if(strcmp(string_buffer, Y_COORDINATE) == 0) /* Value of Y coordinates on the plain. */
				command = Y_COORDINATE_NUMBER;
			else if(strcmp(string_buffer, X_COORDINATE) == 0) /* Value of X coordinates on the plain. */
				command = X_COORDINATE_NUMBER;
			else if(strcmp(string_buffer, CI) == 0) /* Complex imaginary value. */
				command = CI_NUMBER;
			else if(strcmp(string_buffer, CR) == 0) /* Complex real value. */
				command = CR_NUMBER;
			else if(strcmp(string_buffer, ELEMENTS) == 0) /* Pushes the number of elements on to the top of the stack. */
				command = ELEMENTS_NUMBER;
			else /* Store the number. */
			{
				Global_numeric_data[numeric_location] = (double)atof(string_buffer); /* Convert argument into a double. */
				command = PUSH_VARS + numeric_location;
				numeric_location++;
			}

		}
		else if(strcmp(string_buffer, ADD) == 0) /* Addition. */
			command = ADD_NUMBER;
		else if(strcmp(string_buffer, SUB) == 0) /* Subtraction. */
			command = SUB_NUMBER;
		else if(strcmp(string_buffer, MUL) == 0) /* Multiplication. */
			command = MUL_NUMBER;
		else if(strcmp(string_buffer, DIV) == 0) /* Divide. */
			command = DIV_NUMBER;
		else if(strcmp(string_buffer, MOD) == 0) /* Modulus can only be preformed on integer stack. */
			command = MOD_NUMBER;
		else if(strcmp(string_buffer, SHL) == 0) /* Shift left can only be preformed on integer stack. */
			command = SHL_NUMBER;
		else if(strcmp(string_buffer, SHR) == 0) /* Shift right can only be preformed on integer stack. */
			command = SHR_NUMBER;
		else if(strcmp(string_buffer, OR) == 0) /* Or can only be preformed on integer stack. */
			command = OR_NUMBER;
		else if(strcmp(string_buffer, AND) == 0) /* Modulus can only be preformed on integer stack. */
			command = AND_NUMBER;
		else if(strcmp(string_buffer, XOR) == 0) /* Exclusive or can only be preformed on integer stack. */
			command = XOR_NUMBER;
		else if(strcmp(string_buffer, NOT) == 0) /* Not can only be preformed on integer stack. */
			command = NOT_NUMBER;
		else if(strcmp(string_buffer, RETURN) == 0) /* Return to the original call. */
			command = RETURN_NUMBER;
		else if(strcmp(string_buffer, ROT) == 0) /* Rotates the three top most elements (a b c -- b c a). */
			command = ROT_NUMBER;
		else if(strcmp(string_buffer, SWAP) == 0) /* Swaps the two top most elements (a b -- b a). */
			command = SWAP_NUMBER;
		else if(strcmp(string_buffer, OVER) == 0) /* Duplicates the second element and pushes it on top (a b -- a b a). */
			command = OVER_NUMBER;
		else if(strcmp(string_buffer, DUP) == 0) /* Duplicates the first element and pushes it on top (a -- a a). */
			command = DUP_NUMBER;
		else if(strcmp(string_buffer, PEEK) == 0) /* Pushes a copy of the nth element on to the top of the stack pops previous top most element. */
			command = PEEK_NUMBER;
		else if(strcmp(string_buffer, POKE) == 0) /* Pops the two top most elements and places value of the second element into nth stack element. */
			command = POKE_NUMBER;
		else if(strcmp(string_buffer, EXCHANGE) == 0) /* Exchanges the two topmost elements of stack a and stack b. */
			command = EXCHANGE_NUMBER;
		else if(strcmp(string_buffer, LABEL) == 0) /* Just read and read next string to prevent getting counted as an error. */
		{
			program_data[program_data_location] = LABEL_NUMBER; /* Save label instruction. */
			program_data_location++;
			label_creation = TRUE;
		}
		else if(strcmp(string_buffer, EQUAL) == 0) /* Conditional branch if the two elements compared are equal. */
		{
			program_data[program_data_location] = EQUAL_NUMBER; /* Save conditional instruction. */
			program_data_location++;
			label_creation = TRUE;
		}
		else if(strcmp(string_buffer, NOTEQUAL) == 0) /* Conditional branch if the two elements compared are not equal. */
		{
			program_data[program_data_location] = NOTEQUAL_NUMBER; /* Save conditional instruction. */
			program_data_location++;
			label_creation = TRUE;
		}
		else if(strcmp(string_buffer, LESS) == 0) /* Conditional branch if the bottom element is less than the top. */
		{
			program_data[program_data_location] = LESS_NUMBER; /* Save conditional instruction. */
			program_data_location++;
			label_creation = TRUE;
		}
		else if(strcmp(string_buffer, GREATER) == 0) /* Conditional branch if bottom element is greater than the top. */
		{
			program_data[program_data_location] = GREATER_NUMBER; /* Save conditional instruction. */
			program_data_location++;
			label_creation = TRUE;
		}
		else if(strcmp(string_buffer, UNCONDITIONAL) == 0) /* Unconditional jump to the label. */
		{
			program_data[program_data_location] = UNCONDITIONAL_NUMBER; /* Save unconditional instruction. */
			program_data_location++;
			label_creation = TRUE;
		}
		else if(strcmp(string_buffer, CALL) == 0) /* Unconditional call to the label. */
		{
			program_data[program_data_location] = CALL_NUMBER; /* Save call instruction. */
			program_data_location++;
			label_creation = TRUE;
		}
		else
		{
			printf("%s\n", string_buffer);
			error(8);
		}

		if(label_creation == TRUE) /* Create a new label. */
		{
			/* The label to find. */
			sscanf(program_space + word_location, "%s", string_buffer);
			word_location += strlen(string_buffer);
			word_location++;

			unsigned int i = 0;

			for(i = 0 ; i < label_counter ; i++) /* Check if label exists. */
				if(strcmp(string_buffer, label_array[i]) == 0)
				{
					label_creation = FALSE;
					break;
				}

			if(label_creation == TRUE) /* Create new label. */
			{
				strcpy(label_array[label_counter], string_buffer);
				command = label_counter;
				label_counter++;
			}
			else
				command = i;

			label_creation = FALSE;
		}

		program_data[program_data_location] = command; /* Save the instruction. */
		program_data_location++;
	}
	program_data[program_data_location] = (unsigned int)TRUE; /* Used for terminating the array of data. */
	return program_data;
}

/* Used to implement the pop operation for int stacks. */
int popA(int* a_stack)
{
	int temp = 0;

	if(Global_a_stack_elements == -1)
		error(1);

	temp = a_stack[Global_a_stack_elements];
	a_stack[Global_a_stack_elements] = 0;
	Global_a_stack_elements--;
	return temp;
}

/* Used to implement the pop operation for double stacks. */
double popB(double* b_stack)
{
	double temp = 0;

	if(Global_b_stack_elements == -1)
		error(1);

	temp = b_stack[Global_b_stack_elements];
	b_stack[Global_b_stack_elements] = 0;
	Global_b_stack_elements--;
	return temp;
}

/* Used to implement the pop operation for return stacks. */
unsigned int popC(unsigned int* c_stack, unsigned int location)
{
	unsigned int temp = 0;

	if(Global_c_stack_elements == -1) /* Just keep on truckin. */
		return location;

	temp = c_stack[Global_c_stack_elements];
	c_stack[Global_c_stack_elements] = 0;
	Global_c_stack_elements--;
	return temp;
}

/* Used to implement the push operation for int stacks. */
void pushA(int* a_stack, int element)
{
	if(Global_a_stack_elements == Global_stack_size)
		error(2);

	Global_a_stack_elements++;
	a_stack[Global_a_stack_elements] = element;

	return;
}

/* Used to implement the push operation for double stacks. */
void pushB(double* b_stack, double element)
{
	if(Global_b_stack_elements == Global_stack_size)
		error(2);

	Global_b_stack_elements++;
	b_stack[Global_b_stack_elements] = element;

	return;
}

/* Used to implement the push operation for call stack. */
void pushC(unsigned int* c_stack, unsigned int element)
{
	if(Global_c_stack_elements == MAXIMUM_RETURN_STACK)
		error(9);

	Global_c_stack_elements++;
	c_stack[Global_c_stack_elements] = element;

	return;
}

/* Generate the patters and colors used switch statment since all data in switch statment is accessed equally. */
unsigned int color(unsigned int* program_data, unsigned int iterations, int* a_stack, double* b_stack, unsigned int* c_stack)
{
	unsigned char stack_type = INTEGER_STACK; /* Default stack to start on. */
	unsigned int find_label = 0; /* Default label name. */
	unsigned int location = 0;
	char find_flag = FALSE;
	int switch_number = 0;
	int int_temp = 0; /* Temporary integer. */
	double double_temp = 0; /* Temporary double. */

	/* Reads the program and breaks it into sections of strings to be processed. */
	while(switch_number != TRUE)
	{
		/* Find the label if not found then return a error. */
		if(find_flag == TRUE)
		{
			find_flag = FALSE;
			location = 0; /* Start from the top of the array. */

			do
			{
				while(program_data[location] != LABEL_NUMBER)
				{
					if(program_data[location] == TRUE)
						error(11);
					location++;
				}

				location++;

				if(program_data[location] == TRUE)
					error(11);

			}while(program_data[location] != find_label);
			location++;
		}

		switch_number = program_data[location];
		location++;

		switch(switch_number)
		{
			case TERMINATOR_NUMBER: /* Terminate the script. */
				switch_number = TRUE;
				break;

			case INTEGER_STACK_NUMBER: /* Only use stack a.*/
				stack_type = INTEGER_STACK;
				break;

			case ARCH_REAL_STACK_NUMBER: /* Use stack a and b, and store in b.*/
				stack_type = ARCH_REAL_STACK;
				break;

			case ARCH_INTEGER_STACK_NUMBER: /* Use stack a and b, and store in a.*/
				stack_type = ARCH_INTEGER_STACK;
				break;

			case DOUBLE_STACK_NUMBER: /* Only use stack b. */
				stack_type = DOUBLE_STACK;
				break;

			case POP_NUMBER: /* Pop an element from either stack a or b. */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
					popA(a_stack); /* Pop a integer. */
				else
					popB(b_stack); /* Pop a double. */
				break;

			case PUSH_NUMBER: /* Used to store integers, variables, and doubles. */

				switch_number = program_data[location];
				location++;

				if(switch_number == CYCLES_NUMBER) /* Number of iterations to escape Julia set. */
					double_temp = (double)iterations;
				else if(switch_number == Y_COORDINATE_NUMBER) /* Value of Y coordinates on the plain. */
					double_temp = Global_y;
				else if(switch_number == X_COORDINATE_NUMBER) /* Value of X coordinates on the plain. */
					double_temp = Global_x;
				else if(switch_number == CI_NUMBER) /* Complex imaginary value. */
					double_temp = Global_ci;
				else if(switch_number == CR_NUMBER) /* Complex real value. */
					double_temp = Global_cr;
				else if(switch_number == ELEMENTS_NUMBER) /* Pushes the number of elements on to the top of the stack. */
				{
					if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
						double_temp = (double)Global_a_stack_elements;
					else
						double_temp = (double)Global_b_stack_elements;
				}
				else
					double_temp = Global_numeric_data[switch_number - PUSH_VARS]; /* Convert argument into a double. */

				/* Store the variable or number. */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
					pushA(a_stack, (int)double_temp); /* Push a integer. */
				else
					pushB(b_stack, double_temp); /* Push a double. */
				break;

			case ADD_NUMBER: /* Addition. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) + int_temp);
				}
				else if(stack_type == DOUBLE_STACK)
				{
					double_temp = popB(b_stack);
					pushB(b_stack, popB(b_stack) + double_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popB(b_stack);
					pushA(a_stack, popA(a_stack) + (int)double_temp);
				}
				else
				{
					int_temp = popA(a_stack);
					pushB(b_stack, popB(b_stack) + (double)int_temp);
				}
				break;

			case SUB_NUMBER: /* Subtraction. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) - int_temp);
				}
				else if(stack_type == DOUBLE_STACK)
				{
					double_temp = popB(b_stack);
					pushB(b_stack, popB(b_stack) - double_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popB(b_stack);
					pushA(a_stack, popA(a_stack) - (int)double_temp);
				}
				else
				{
					int_temp = popA(a_stack);
					pushB(b_stack, popB(b_stack) - (double)int_temp);
				}
				break;

			case MUL_NUMBER: /* Multiplication. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) * int_temp);
				}
				else if(stack_type == DOUBLE_STACK)
				{
					double_temp = popB(b_stack);
					pushB(b_stack, popB(b_stack) * double_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popB(b_stack);
					pushA(a_stack, popA(a_stack) * (int)double_temp);
				}
				else
				{
					int_temp = popA(a_stack);
					pushB(b_stack, popB(b_stack) * (double)int_temp);
				}
				break;

			case DIV_NUMBER: /* Divide. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
	
					if(int_temp != 0) /* Cannot divide by zero! */
						pushA(a_stack, popA(a_stack) / int_temp);
					else
						pushA(a_stack, int_temp);
				}
				else if(stack_type == DOUBLE_STACK)
				{
					double_temp = popB(b_stack);
	
					if(double_temp != 0) /* Cannot divide by zero! */
						pushB(b_stack, popB(b_stack) / double_temp);
					else
						pushB(b_stack, double_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popB(b_stack);
	
					if(double_temp != 0) /* Cannot divide by zero! */
						pushA(a_stack, popA(a_stack) / double_temp);
					else
						pushB(b_stack, double_temp);
				}
				else
				{
					int_temp = popA(a_stack);
	
					if(int_temp != 0) /* Cannot divide by zero! */
						pushB(b_stack, popB(b_stack) / int_temp);
					else
						pushA(a_stack, int_temp);
				}
				break;

			case MOD_NUMBER: /* Modulus can only be preformed on integer stack. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
	
					if(int_temp != 0) /* Cannot modulus by zero! */
						pushA(a_stack, popA(a_stack) % int_temp);
					else
						pushA(a_stack, int_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popA(a_stack);
	
					if(double_temp != 0) /* Cannot modulus by zero! */
						pushA(a_stack, popA(a_stack) % (int)double_temp);
					else
						pushB(b_stack, double_temp);
				}
				else
					error(7);
				break;

			case SHL_NUMBER: /* Shift left can only be preformed on integer stack. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) << int_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) << (int)double_temp);
				}
				else
					error(7);
				break;

			case SHR_NUMBER: /* Shift right can only be preformed on integer stack. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) >> int_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) >> (int)double_temp);
				}
				else
					error(7);
				break;

			case OR_NUMBER: /* Or can only be preformed on integer stack. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) | int_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) | (int)double_temp);
				}
				else
					error(7);
				break;

			case AND_NUMBER: /* Modulus can only be preformed on integer stack. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) & int_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) & (int)double_temp);
				}
				else
					error(7);
				break;

			case XOR_NUMBER: /* Exclusive or can only be preformed on integer stack. */
				if(stack_type == INTEGER_STACK)
				{
					int_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) ^ int_temp);
				}
				else if(stack_type == ARCH_INTEGER_STACK)
				{
					double_temp = popA(a_stack);
					pushA(a_stack, popA(a_stack) ^ (int)double_temp);
				}
				else
					error(7);
				break;

			case NOT_NUMBER: /* Not can only be preformed on integer stack. */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
					pushA(a_stack, ~popA(a_stack));
				else
					error(7);
				break;

			case LABEL_NUMBER: /* Just read and read next string to prevent getting counted as an error. */
				location++;
				break;

			case EQUAL_NUMBER: /* Conditional branch if the two elements compared are equal. */
				/* The label to find. */
				find_label = program_data[location];
				location++;
	
				if(stack_type == INTEGER_STACK && popA(a_stack) == popA(a_stack))
					find_flag = TRUE;
				else if(stack_type == DOUBLE_STACK && popB(b_stack) == popB(b_stack))
					find_flag = TRUE;
				else if(stack_type == ARCH_INTEGER_STACK && popA(a_stack) == (int)popB(b_stack)) /* Due to the casting the numbers could be different. */
					find_flag = TRUE;
				else if(stack_type == ARCH_REAL_STACK && (double)popA(a_stack) == popB(b_stack))
					find_flag = TRUE;
				break;

			case NOTEQUAL_NUMBER: /* Conditional branch if the two elements compared are not equal. */
				/* The label to find. */
				find_label = program_data[location];
				location++;
	
				if(stack_type == INTEGER_STACK && popA(a_stack) != popA(a_stack))
					find_flag = TRUE;
				else if(stack_type == DOUBLE_STACK && popB(b_stack) != popB(b_stack))
					find_flag = TRUE;
				else if(stack_type == ARCH_INTEGER_STACK && popA(a_stack) != (int)popB(b_stack)) /* Due to the casting the numbers could be different. */
					find_flag = TRUE;
				else if(stack_type == ARCH_REAL_STACK && (double)popA(a_stack) != popB(b_stack))
					find_flag = TRUE;
				break;

			case LESS_NUMBER: /* Conditional branch if the bottom element is less than the top. */
				/* The label to find. */
				find_label = program_data[location];
				location++;
	
				if(stack_type == INTEGER_STACK && popA(a_stack) < popA(a_stack))
					find_flag = TRUE;
				else if(stack_type == DOUBLE_STACK && popB(b_stack) < popB(b_stack))
					find_flag = TRUE;
				else if(stack_type == ARCH_INTEGER_STACK && popA(a_stack) < (int)popB(b_stack)) /* Due to the casting the numbers could be different. */
					find_flag = TRUE;
				else if(stack_type == ARCH_REAL_STACK && popA(a_stack) < (double)popA(a_stack))
					find_flag = TRUE;
				break;

			case GREATER_NUMBER: /* Conditional branch if bottom element is greater than the top. */
				/* The label to find. */
				find_label = program_data[location];
				location++;
	
				if(stack_type == INTEGER_STACK && popA(a_stack) > popA(a_stack))
					find_flag = TRUE;
				else if(stack_type == DOUBLE_STACK && popB(b_stack) > popB(b_stack))
					find_flag = TRUE;
				else if(stack_type == ARCH_INTEGER_STACK && popA(a_stack) > (int)popB(b_stack)) /* Due to the casting the numbers could be different. */
					find_flag = TRUE;
				else if(stack_type == ARCH_REAL_STACK && popA(a_stack) > (double)popA(a_stack))
					find_flag = TRUE;
				break;

			case UNCONDITIONAL_NUMBER: /* Unconditional jump to the label. */
				find_label = program_data[location];
				find_flag = TRUE;
				break;

			case CALL_NUMBER: /* Unconditional call to the label. */
				/* The label to find. */
				find_label = program_data[location];
				location++;
	
				find_flag = TRUE;
				pushC(c_stack, location); /* Used to store the addresses of addresses to return to. */
				break;

			case RETURN_NUMBER: /* Return to the original call. */
				location = popC(c_stack, location);
				break;

			case ROT_NUMBER: /* Rotates the three top most elements (a b c -- b c a). */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
				{
					int_temp = popA(a_stack); /* Top element. */
					int int_temp_2 = popA(a_stack); /* Second element. */
					int int_temp_3 = popA(a_stack); /* Thrid element. */
					pushA(a_stack, int_temp_2);
					pushA(a_stack, int_temp);
					pushA(a_stack, int_temp_3); /* New top element. */
				}
				else
				{
					double_temp = popB(b_stack); /* Top element. */
					double double_temp_2 = popB(b_stack); /* Second element. */
					double double_temp_3 = popB(b_stack); /* Thrid element. */
					pushB(b_stack, double_temp_2);
					pushB(b_stack, double_temp);
					pushB(b_stack, double_temp_3); /* New top element. */
				}
				break;

			case SWAP_NUMBER: /* Swaps the two top most elements (a b -- b a). */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
				{
					int_temp = popA(a_stack); /* Top element. */
					int int_temp_2 = popA(a_stack); /* Second element. */
					pushA(a_stack, int_temp);
					pushA(a_stack, int_temp_2); /* New top element. */
				}
				else
				{
					double_temp = popB(b_stack); /* Top element. */
					double double_temp_2 = popB(b_stack); /* Second element. */
					pushB(b_stack, double_temp);
					pushB(b_stack, double_temp_2); /* New top element. */
				}
				break;

			case OVER_NUMBER: /* Duplicates the second element and pushes it on top (a b -- a b a). */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
				{
					int_temp = popA(a_stack); /* Top element. */
					int int_temp_2 = popA(a_stack); /* Second element. */
					pushA(a_stack, int_temp_2);
					pushA(a_stack, int_temp);
					pushA(a_stack, int_temp_2); /* New top element. */
				}
				else
				{
					double_temp = popB(b_stack); /* Top element. */
					double double_temp_2 = popB(b_stack); /* Second element. */
					pushB(b_stack, double_temp_2);
					pushB(b_stack, double_temp);
					pushB(b_stack, double_temp_2); /* New top element. */
				}
				break;

			case DUP_NUMBER: /* Duplicates the first element and pushes it on top (a -- a a). */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
				{
					int_temp = popA(a_stack); /* Top element. */
					pushA(a_stack, int_temp);
					pushA(a_stack, int_temp); /* New top element. */
				}
				else
				{
					double_temp = popB(b_stack); /* Top element. */
					pushB(b_stack, double_temp);
					pushB(b_stack, double_temp); /* New top element. */
				}
				break;

			case PEEK_NUMBER: /* Pushes a copy of the nth element on to the top of the stack pops previous top most element. */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
				{
					int_temp = (unsigned int)popA(a_stack);
	
					if((unsigned int)int_temp > Global_stack_size) /* Cannot be larger than maximum stack size. */
						error(10);
	
					pushA(a_stack, a_stack[(unsigned int)int_temp]); /* New top element. */
				}
				else
				{
					int_temp = (unsigned int)popB(b_stack);
	
					if((unsigned int)int_temp > Global_stack_size) /* Cannot be larger than maximum stack size. */
						error(10);
	
					pushB(b_stack, b_stack[(unsigned int)int_temp]); /* New top element. */
				}
				break;

			case POKE_NUMBER: /* Pops the two top most elements and places value of the second element into nth stack element. */
				if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
				{
					int_temp = (unsigned int)popA(a_stack);
	
					if((unsigned int)int_temp > Global_stack_size) /* Cannot be larger than maximum stack size. */
						error(10);
	
					a_stack[(unsigned int)int_temp] = popA(a_stack); /* New top element. */
				}
				else
				{
					int_temp = (unsigned int)popB(b_stack);
	
					if((unsigned int)int_temp > Global_stack_size) /* Cannot be larger than maximum stack size. */
						error(10);
	
					b_stack[(unsigned int)int_temp] = popB(b_stack); /* New top element. */
				}
				break;

			case EXCHANGE_NUMBER: /* Exchanges the two topmost elements from stack a and stack b. */
				double_temp = popB(b_stack);
				int_temp = popA(a_stack);
				pushA(a_stack, (int)double_temp);
				pushB(b_stack, (double)int_temp);
				break;
		}
	}
	/* Criteria to display integer. */
	if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
		return popA(a_stack);
	return popB(b_stack);

/* --- USED FOR DEBUGGING ---
	if(stack_type == INTEGER_STACK || stack_type == ARCH_INTEGER_STACK)
	{
		int_temp = popA(a_stack);
		printf("int: %d\n", int_temp);
		return (unsigned int)int_temp;
	}
	else
	{
		double_temp = popB(b_stack);
		printf("double: %lf\n", double_temp);
		return (unsigned int)double_temp;
	}*/
}

/* Evaluates the Julia set. */
unsigned int createDetail(double x, double y, double cr, double ci, unsigned int max_iteration)
{
	unsigned int i = 0;
	double tempx = 0;
	double XSquare = x * x; /* Keep these here. Use the pathagorean therom to check if the x and y values have escaped the julia set. */
	double YSquare = y * y;

	/* Zn+1 = Zn^2 + C, while Z <= 2 and < maximum amount of irritations.*/
	while((XSquare + YSquare < 4.0) && (i < max_iteration))
	{
		XSquare = x * x; /* Used to save on operations performed which saves time. */
		YSquare = y * y;
		tempx = (XSquare - YSquare) + cr;
		y = (2 * x * y) + ci; /* x has to be preserved for this equation. */
		x = tempx;
		i++;
	}

	/* Setup the variables for the color function. 
	Used globals since did not want to return a malloc with multipul data types. */
	Global_y = y;
	Global_x = x;
	Global_cr = cr;
	Global_ci = ci;

	return i;
}

/* Creates the coordinate of a point from the bit map image plane into the complex plane.
screen refers to the x or y axis length and the middle is the literal middle in the computerized plane in memory.
The shift right by one is equal to multiplication by two.
Note: Shifts can only be applied to integers doubles cannot be shifted properly.
Note: Automatically sets itself negative or zero if need be. */

double coordinate(double screen, double middle)
{
	return ((screen - middle) / middle) * 2;
}

/* Finds the middle of the bit map image plane. */
double middle(unsigned int plane)
{
	if(plane & 1 == 1)
		return (plane >> 1) + 1; /* Divide by 2 and add one to make it even. */
	return plane >> 1;
}

/* Extracts a byte from anything less than or equal to a long.
Useage: integer_to_extract_from, byte_from_integer 
when extracting aa bb cc dd is output if the integer is ddccbbaa going from 0 to 4. */

unsigned char byteExtractor(unsigned int integer_to_extract_from, char place)
{	
	while(place != 0)
	{
		integer_to_extract_from >>= 8;
		place--;
	}
	
	return (unsigned char)integer_to_extract_from; /* char mask is used to remove unneeded bytes. */
}

/* Creates a new bitmap image.
NOTE: 32K x 32K is the accepted maximum. Yet the image has to be loaded into memory.
So the maximum resolution can vary from system to system depending on the amount of aviable RAM. */

char writeBmp(int width, int height, int xpixel, int ypixel, char *file_name, char *data, unsigned int data_size)
{
	
	FILE* file_pointer = fopen(file_name, "wb");
	
	if(file_pointer == NULL)
		error(5);

	unsigned int bmp_size = data_size + DATA_START; /* Size of BMP data with the 54 byte header. */
	char* file_header = (char*)calloc(DATA_START, sizeof(unsigned char)); /* Allocate 54 bytes of zeros for bmp header. */
	
	if(file_header == 0) /* An error occured. */
		error(4);
	
	/* --- Initilize bmp header --- */
	file_header[0] = 'B'; /* File type header "BM". */
	file_header[1] = 'M';
	file_header[2] = byteExtractor(bmp_size, 0); /* Data of the file size. */
	file_header[3] = byteExtractor(bmp_size, 1);
	file_header[4] = byteExtractor(bmp_size, 2);
	file_header[5] = byteExtractor(bmp_size, 3);
	file_header[10] = DATA_START; /* Skip a few reserved bytes and store the data offset. */
	file_header[14] = INFO_SIZE; /* Size of the info header. */
	file_header[18] = byteExtractor(width, 0); /* Width of the bmp image. */
	file_header[19] = byteExtractor(width, 1);
	file_header[20] = byteExtractor(width, 2);
	file_header[21] = byteExtractor(width, 3);
	file_header[22] = byteExtractor(height, 0); /* height of the bmp image. */
	file_header[23] = byteExtractor(height, 1);
	file_header[24] = byteExtractor(height, 2);
	file_header[25] = byteExtractor(height, 3);
	file_header[26] = PLANES; /* Number of visible planes. */
	file_header[28] = BITCOUNT; /* Skip a byte and set the number of bits per pixel. */
	file_header[38] = byteExtractor(xpixel, 0); /* Skip compression bytes and set the pixel width of the bmp image. */
	file_header[39] = byteExtractor(xpixel, 1);
	file_header[40] = byteExtractor(xpixel, 2);
	file_header[41] = byteExtractor(xpixel, 3);
	file_header[42] = byteExtractor(ypixel, 0); /* Pixel height of the bmp image. */
	file_header[43] = byteExtractor(ypixel, 1);
	file_header[44] = byteExtractor(ypixel, 2);
	file_header[45] = byteExtractor(ypixel, 3);

	fwrite(file_header, 1, DATA_START, file_pointer);
	fwrite(data, 1, data_size, file_pointer);
	free(file_header);
	fclose(file_pointer);
	
	return 0;
}

/* Usage: artcomp
	-I (double) - ci value.
	-R (double) - cr value
	-M (unsigned int) - Maximum number of iterations.
	-W (unsigned int) - Width of the image in pixels.
	-H (unsigned int) - Height of image in pixels.
	-w (unsigned int) - Width of the resolution pixels per meter (for printer).
	-h (unsigned int) - Heigth of the resolution pixels per meter (for printer).
	-S (unsigned int) - Size of the integer and double stacks.
	-O (string) - Name of the file to output MUST ADD *.bmp or equivlent inorder to read the output file.
	-C (string) - Name of the color configuration file to load (reads ASCII).
	*/
int main(int argument_count, char *argument_variable[])
{
	double ci = 0; /* Set by user: The initial center for the imaginary (y) component. */
	double cr = 0; /* Set by user: The initial center for the real (x) component. */
	double y_grid = 0; /* The complex plane coordinates of the imaginary z component. */
	double x_grid = 0; /* The complex plane coordinates of the real z component. */
	unsigned int max_iteration = 0; /* The maximum number of possible irritations that will produce color. */
	unsigned int padding = 0; /* BMP files require each line to be divisible by four so padding is included. */
	unsigned int location = 0; /* Pointer for the location in memory of the BMP data. */
	unsigned int pixel = 0; /* An individual pixel. */
	unsigned int width = 0; /* Width in pixels. */
	unsigned int height = 0; /* Height in pixels.*/
	unsigned int xpixel = 0; /* Pixel per meter resolution x axis. */
	unsigned int ypixel = 0; /* Pixel per meter resolution y axis. */
	int i = 0; /* Used while parsing the command line (0 = name of program, 1 = first argument). */
	char* config_data = 0; /* Pointer for the memory file loaded into memory. */
	int* program_data = 0; /* Pointer for executable scripting commands. */
	char* config_name; /* Used to store the pointer of the -L command line argument. */
	char* output_name; /* Used to store the pointer of the -O command line argument. */
	time_t time_start = time(NULL); /* Start of the time for the program to execute. */

	puts("Copyright (c) 2018 - Andy Cox V - artcomp.bin\n"
"This program produces Julia set fractals to the specifications given by the user.\n"
"Usage: artcomp.bin [Arguments]\n"
"\t-R (double)\t- Complex number real value.\n"
"\t-I (double)\t- Complex number imaginary value.\n"
"\t-M (unsigned int)\t- Maximum number of iterations to compute in Julia set.\n"
"\t-S (unsigned int)\t- Maximum number of elements in both integer and double stacks.\n"
"\t-W (unsigned int)\t- Width of fractal image in pixels.\n"
"\t-H (unsigned int)\t- Height of fractal image in pixels.\n"
"\t-w (unsigned int)\t- Width of fractal image resolution pixels per meter (for printer).\n"
"\t-h (unsigned int)\t- Height of fractal image resolution pixels per meter (for printer).\n"
"\t-C (string)\t- Name of the configuration file to load reads in plain text (ASCII).\n"
"\t-O (string)\t- Name of the fractal image file saved as a 24-bit bitmap image (MUST INCLUDE FILE EXTENTIONS *.bmp OR EQUEVELENT).");

	/* Parse command line arguments. */
	if(argument_count < ARGUMENTS) /* Need a specific number of command line arguments. Can go over due to other console instructions, but not under. */
		error(3);

	/* Take action on the arguments. */
	do
	{
		i++;
		if(strcmp(argument_variable[i], "-I") == 0) /* Load ci. */
	{
		i++;
		ci = (double)atof(argument_variable[i]);
	}
	else if(strcmp(argument_variable[i], "-R") == 0) /* Load cr. */
	{
		i++;
		cr = (double)atof(argument_variable[i]);
	}
	else if(strcmp(argument_variable[i], "-M") == 0) /* Load maximum number of iterations. */
	{
		i++;
		max_iteration = (unsigned int)atoi(argument_variable[i]);
	}
	else if(strcmp(argument_variable[i], "-W") == 0) /* Load width of image in pixels. */
	{
		i++;
		width = (unsigned int)atoi(argument_variable[i]);
	}
	else if(strcmp(argument_variable[i], "-H") == 0) /* Load heigth of image in pixels. */
	{
		i++;
		height = (unsigned int)atoi(argument_variable[i]);
	}
	else if(strcmp(argument_variable[i], "-w") == 0) /* Load width of resolution in pixels per meter. */
	{
		i++;
		xpixel = (unsigned int)atoi(argument_variable[i]);
	}
	else if(strcmp(argument_variable[i], "-h") == 0) /* Load heigth of resolution in pixels per meter. */
	{
		i++;
		ypixel = (unsigned int)atoi(argument_variable[i]);
	}
	else if(strcmp(argument_variable[i], "-S") == 0) /* Load size of the stacks. */
	{
		i++;
		Global_stack_size = (unsigned int)atoi(argument_variable[i]);
	}
	else if(strcmp(argument_variable[i], "-C") == 0) /* Load output file name. */
	{
		i++;
		config_name = argument_variable[i];
	}
	else if(strcmp(argument_variable[i], "-O") == 0) /* Load color configuration file. */
	{
		i++;
		output_name = argument_variable[i];
	}
	else
		error(6);
	}while(i < COMPUTATION_ARGUMENT_COUNT);

	printf("\n---OVERVIEW---\n"
	"Real value of C: %f\n"
	"Imaginary value of C: %f\n"
	"Maximum number of iterations: %d\n"
	"Elements per stack: %d\n"
	"Width of image in pixels: %d\n"
	"Height of image in pixels: %d\n"
	"Width of image in pixels per meter: %d\n"
	"Height of image in pixels per meter: %d\n"
	"Configuration file name: %s\n"
	"Output file name: %s\n\n", cr, ci, max_iteration, Global_stack_size, width, height, xpixel, ypixel, config_name, output_name);

	printf("Reading configuration file: %s\n", config_name);

	config_data = loadConfig(config_name);
	program_data = load(config_data);
	free(config_data);

	/* --- Find padding bytes size ---
	Calculates the number of bytes needed for padding the rows of a bmp file.
	Bmp files need to have rows in multiples of four. */

	while((((width * BYTES_PER_PIXEL) + padding) % 4) != 0)
	padding++;

	/* Initilize non-user defined variables. */
	
	double y_middle = middle(height); /* Find the middle of the height, set to double for coordinate function. */
	double x_middle = middle(width); /* Find the middle of the width, set to double for coordinate function. */
	unsigned int bmp_size = (width * height * BYTES_PER_PIXEL) + (padding * height);
	
	char* file_data = (char*)malloc(bmp_size); /* Section off enough memory for the fractal. */

	if(file_data == 0)
		error(4);
	
	puts("Processing...");

	/* Iterate through the screen to produce the fractal image.
	NOTE: Iterators are set to double for the coordinate function. */
	for(double y_screen = 0 ; y_screen < height ; y_screen++)
	{
		for(double x_screen = 0 ; x_screen < width ; x_screen++)
		{
			x_grid = coordinate(x_screen, x_middle);
			y_grid = coordinate(y_screen, y_middle);

			/* Create stacks for the program. */
			int* int_stack = (int*)malloc(Global_stack_size * sizeof(int)); /* Allocate memory and create the pointer for the int stack. */
			double* double_stack = (double*)malloc(Global_stack_size * sizeof(double)); /* Allocate memory and create the pointer for the double stack. */
			unsigned int* return_stack = (unsigned int*)malloc(MAXIMUM_RETURN_STACK * sizeof(unsigned int)); /* Allocate memory and create the pointer for the unsigned int stack. */
			Global_a_stack_elements = -1; /* Keep a log of the top most element and the number of elements in the stack. */
			Global_b_stack_elements = -1;
			Global_c_stack_elements = -1;

			pixel = color(program_data, createDetail(x_grid, y_grid, cr, ci, max_iteration), int_stack, double_stack, return_stack);

			free(int_stack); /* Remove old stacks from memory. */
			free(double_stack);
			free(return_stack);

			/*printf("Percent Complete: %f\r", ((double)location / (double)bmp_size) * 100);
			fflush(stdout); -- Commented due to slowing down program expontentially. */
		
			/* Pixel data is placed here in relation to the memory location. */
			file_data[location] = byteExtractor(pixel, 0);
			location++;
			file_data[location] = byteExtractor(pixel, 1);
			location++;
			file_data[location] = byteExtractor(pixel, 2);
			location++;
		}
	printf("%f%%\r", ((double)location / (double)bmp_size) * 100); /* Place this here so an if statment does not have to be executed. */
	location += padding;
	}

	printf("%f%%\nWriting to file: %s\n", ((double)location / (double)bmp_size) * 100, output_name);

	writeBmp(width, height, xpixel, ypixel, output_name, file_data, bmp_size);
	free(file_data);

	printf("Completed in %ld seconds!\n", (time_t)time(NULL) - time_start);

	return 0;
}