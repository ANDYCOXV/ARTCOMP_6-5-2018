#Author: Andy Cox V
#Date: 4/9/2018
#This script is an example of a runable set of correct terminal arguments for ARTCOMP using the power.txt pattern.
#chmod +x run.sh and chmod +x artcomp.bin may need to be ran if a PERMISSION DENIED! error is given by the operating system when attemping to run these programs.
#This this script and artcomp.bin sucessfully ran on an lUbuntu system.
./artcomp.bin -S 100 -H 4096 -W 4096 -R 0.285 -I -0.8 -M 65535 -O power.bmp -C power.txt -w 1200 -h 1200